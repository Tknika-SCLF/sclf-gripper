/**
 * SCLF Gripper v1.0 — Firmware
 * Board:     STM32G474CEU6
 * Framework: Arduino (STM32duino) via PlatformIO
 * Library:   SimpleFOC
 *
 * ─── FASE 0 — Smoke Test ───────────────────────────────────────────────────
 * Objetivo: verificar que el entorno compila, el ST-Link programa la placa,
 * el LED parpadea y el USB VCP responde.
 *
 * NO hay FOC aquí todavía. El motor NO se mueve en esta fase.
 * ───────────────────────────────────────────────────────────────────────────
 */

#include <Arduino.h>
#include "config/pins.h"

// ── Constantes ───────────────────────────────────────────────────────────────
static constexpr uint32_t LED_BLINK_PERIOD_MS = 500;
static constexpr uint32_t VCP_PRINT_PERIOD_MS = 1000;
static constexpr uint32_t VCP_BAUD             = 115200;

// ── Estado ───────────────────────────────────────────────────────────────────
static uint32_t lastLedToggle  = 0;
static uint32_t lastVcpPrint   = 0;
static uint32_t loopCount      = 0;
static bool     ledState       = false;

// ── setup() ──────────────────────────────────────────────────────────────────
void setup() {
    // USB Virtual COM Port
    Serial.begin(VCP_BAUD);
    uint32_t t = millis();
    while (!Serial && (millis() - t) < 3000) {}   // esperar max 3s a que abra el monitor

    Serial.println("========================================");
    Serial.println("  SCLF Gripper v1.0 — Firmware FASE 0  ");
    Serial.println("========================================");
    Serial.print("  MCU: STM32G474CEU6 @ ");
    Serial.print(F_CPU / 1000000);
    Serial.println(" MHz");
    Serial.println("  Estado: SMOKE TEST (sin FOC, sin motor)");
    Serial.println("========================================");

    // LED de estado
    pinMode(PIN_LED, OUTPUT);
    digitalWrite(PIN_LED, LOW);

    // RS-485: mantener en modo RX (no transmitir nada todavía)
    pinMode(PIN_RS485_DIR, OUTPUT);
    digitalWrite(PIN_RS485_DIR, LOW);   // LOW = RX

    // BOOT pin (entrada, ya tiene pull-down externo por BOOT0)
    pinMode(PIN_BOOT, INPUT);

    Serial.println("  Pines inicializados correctamente.");
    Serial.println("  Blink LED cada 500ms. Escribe cualquier");
    Serial.println("  caracter en el monitor para eco.");
    Serial.println("----------------------------------------");
}

// ── loop() ───────────────────────────────────────────────────────────────────
void loop() {
    uint32_t now = millis();
    loopCount++;

    // ── LED blink (non-blocking) ──────────────────────────────────────────
    if ((now - lastLedToggle) >= LED_BLINK_PERIOD_MS) {
        ledState = !ledState;
        digitalWrite(PIN_LED, ledState ? HIGH : LOW);
        lastLedToggle = now;
    }

    // ── VCP telemetría periódica ──────────────────────────────────────────
    if ((now - lastVcpPrint) >= VCP_PRINT_PERIOD_MS) {
        Serial.print("[");
        Serial.print(now / 1000);
        Serial.print("s] loops/s≈");
        Serial.print(loopCount);
        Serial.print("  LED=");
        Serial.println(ledState ? "ON" : "OFF");
        loopCount    = 0;
        lastVcpPrint = now;
    }

    // ── Eco de caracteres recibidos por VCP ──────────────────────────────
    if (Serial.available()) {
        char c = Serial.read();
        Serial.print("  Echo: '");
        Serial.print(c);
        Serial.println("'");
    }
}
